# IndiForge.AI Starter

Simple React app to connect Phantom Wallet and upload a dataset.

## Setup
1. Install Node.js
2. Run:
   npm install
   npm start

Ensure Phantom Wallet is installed.